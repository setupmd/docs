\---------------------------------------/
 To use this Deluxe Menus Shop, You need
 to install the following:
   - Vault (Duh)
   - PlaceHolderAPI (Duh) + Vault, Math,
     CheckItem Expansions.
   - DeluxeMenus (Duh)
\---------------------------------------/